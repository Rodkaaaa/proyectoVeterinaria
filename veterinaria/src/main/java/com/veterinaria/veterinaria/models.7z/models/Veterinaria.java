package com.veterinaria.veterinaria.models;

public class Veterinaria extends Persona {
    static int IdAutoVeterinaria = 0;
    String _nombre,_direccion,_email;
    Persona _persona;
    
    public Veterinaria() {
        super();
    }


    
    
}
